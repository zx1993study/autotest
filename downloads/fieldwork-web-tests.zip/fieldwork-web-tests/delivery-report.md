# 外勤小星管理端 Web 脚本交付

交付日期：2026-10-19（Asia/Shanghai）

源码已下载至 `D:\project\Fieldwork-management`，版本 `250b6bc4d4e56f1e5136f701e1344590fd24e849`。

## 生成与保存

- 核对现有 287 个页面功能，生成 51 份页面展示/查询脚本。
- 平台保存 51 份 draft 版本，不把源码生成等同运行验证。
- 正式用例保存前后均为 11 条；没有新建或删除用例。
- 原仓库查询用例 #31 保持 ID、名称、优先级和 WH001 输入，绑定当前统一条件查询组件；保留旧步骤追溯。
- 其他 10 条已有用例保持原样。236 个未生成完整脚本的页面功能已逐项列出阻塞原因。

## 实际回放

只读抽查 5 项，结果：{'passed': 5}。未执行新增、编辑、删除、审批等写场景。
| 功能 ID | 用例 ID | 范围 | 结果 |
|---:|---:|---|---|
| 11512 | 31 | 原条件查询：请求参数、业务码、逐条过滤和重置 | passed |
| 11362 | - | 列表查询冒烟，非完整业务链路 | passed |
| 11378 | - | 列表查询冒烟，非完整业务链路 | passed |
| 11394 | - | 列表查询冒烟，非完整业务链路 | passed |
| 11421 | - | 列表查询冒烟，非完整业务链路 | passed |

## 仍需补充

- 登录用例需确认各自预期结果、账号密码参数与人工验证码；不绕过验证码。
- 旧仓库删除用例没有本轮对象 ID 和精确行范围，不能据此删除历史仓库。
- 仓库新增录制包含空下拉值，且部分路径以取消结束；需要确认业务期望后再形成新增成功脚本。
- 活动模板新增在平台被标成 page 类型且录制含不完整定位，不能替换为列表展示冒充新增验证。
- 旧路径、动态参数和自定义控件均不猜测；见 generation-report.md。

## 文件

- README.md：目录与运行命令。
- generation-report.md：全部功能和已有用例的生成状态。
- publish-results.json：平台脚本版本和原用例 ID。
- results/read-only-verification.json：真实只读回放结果，不含 Token、截图或客户响应明细。
- 持久化完整性：{'project_id': 10, 'versions': 51, 'draft_versions': 51, 'existing_cases': 11, 'case_ids_unchanged': True, 'linked_case_id': 31, 'linked_version_id': 17628, 'legacy_steps_preserved': True, 'candidate_schema_valid': True}。

脚本只读模式阻止非 GET/HEAD/OPTIONS 请求，不消费 AI Token。平台版本仍保留 draft；其余脚本尚未逐一真实回放，不报告为全部通过。
